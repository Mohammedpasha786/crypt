# This file is only for editing file nodes, do not break the structure

/src
├── assets/          # Static resources directory, storing static files like images and fonts
│
├── components/      # Components directory
│   ├── ui/         # Pre-installed shadcn/ui components, avoid modifying or rewriting unless necessary
│   ├── layout/     # Layout components for the blog
│   │   ├── Header.tsx # Navigation header component
│   │   ├── Footer.tsx # Footer component
│   │   └── Layout.tsx # Main layout wrapper component
│   └── blog/       # Blog-specific components
│       ├── BlogCard.tsx       # Blog article card component
│       ├── CategoryList.tsx   # List of blog categories
│       ├── FeaturedPost.tsx   # Featured post hero component
│       ├── NewsletterSubscribe.tsx # Newsletter subscription component
│       └── PopularTags.tsx    # Popular tags component
│
├── data/           # Data directory for mock data
│   └── mockData.ts # Mock data for blog articles, categories, authors, etc.
│
├── hooks/          # Custom Hooks directory
│   ├── use-mobile.ts # Pre-installed mobile detection Hook from shadcn (import { useIsMobile } from '@/hooks/use-mobile')
│   └── use-toast.ts  # Toast notification system hook for displaying toast messages (import { useToast } from '@/hooks/use-toast')
│
├── lib/            # Utility library directory
│   └── utils.ts    # Utility functions, including the cn function for merging Tailwind class names
│
├── pages/          # Page components directory, based on React Router structure
│   ├── HomePage.tsx          # Home page component with featured posts and latest articles
│   ├── ArticlesPage.tsx      # Page listing all blog articles with filtering
│   ├── ArticleDetailPage.tsx # Detailed view of an individual article
│   ├── CategoriesPage.tsx    # Page listing all blog categories
│   ├── CategoryDetailPage.tsx # Detailed view of articles in a category
│   ├── AboutPage.tsx         # About page with information about the blog
│   ├── CreateArticlePage.tsx # Page for creating new blog articles
│   └── NotFoundPage.tsx      # 404 error page component, displays when users access non-existent routes
│
├── App.tsx         # Root component, with React Router routing system configured
│                   # Contains routes for all pages
│
├── main.tsx        # Entry file, rendering the root component and mounting to the DOM
│
├── index.css       # Global styles file, containing Tailwind configuration and custom styles
│                   # Contains blog-specific styles
│
└── tailwind.config.js  # Tailwind CSS v3 configuration file
                      # Contains theme customization, plugins, and content paths
                      # Includes shadcn/ui theme configuration 