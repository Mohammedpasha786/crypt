import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { 
  Menu,
  Search,
  PenSquare
} from "lucide-react";

const navItems = [
  { name: "Home", path: "/" },
  { name: "Articles", path: "/articles" },
  { name: "Categories", path: "/categories" },
  { name: "About", path: "/about" },
];

export default function Header() {
  const { pathname } = useLocation();
  const isMobile = useIsMobile();
  const [isSearchVisible, setIsSearchVisible] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl font-semibold">
              <span className="text-primary">Blogsy</span>
            </span>
          </Link>
        </div>

        {!isMobile && (
          <nav className="hidden gap-6 md:flex">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  pathname === item.path
                    ? "text-foreground"
                    : "text-muted-foreground"
                )}
              >
                {item.name}
              </Link>
            ))}
          </nav>
        )}

        <div className="flex items-center gap-2">
          {!isMobile && (
            <div className="flex gap-1">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setIsSearchVisible(!isSearchVisible)}
              >
                <Search className="h-5 w-5" />
                <span className="sr-only">Search</span>
              </Button>
              <Button asChild className="gap-1">
                <Link to="/create">
                  <PenSquare className="h-4 w-4" />
                  Write
                </Link>
              </Button>
            </div>
          )}

          {isMobile && (
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsSearchVisible(!isSearchVisible)}
              >
                <Search className="h-5 w-5" />
                <span className="sr-only">Search</span>
              </Button>
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <SheetHeader>
                    <SheetTitle>Blogsy</SheetTitle>
                    <SheetDescription>
                      Your space to speak
                    </SheetDescription>
                  </SheetHeader>
                  <nav className="flex flex-col gap-4 mt-4">
                    {navItems.map((item) => (
                      <Link
                        key={item.path}
                        to={item.path}
                        className={cn(
                          "text-base font-medium transition-colors hover:text-primary",
                          pathname === item.path
                            ? "text-primary"
                            : "text-muted-foreground"
                        )}
                      >
                        {item.name}
                      </Link>
                    ))}
                    <Button asChild className="gap-1 mt-2">
                      <Link to="/create">
                        <PenSquare className="h-4 w-4" />
                        Write
                      </Link>
                    </Button>
                  </nav>
                </SheetContent>
              </Sheet>
            </div>
          )}
        </div>
      </div>

      {/* Search bar that slides down when search is clicked */}
      <div 
        className={cn(
          "w-full bg-background border-b overflow-hidden transition-all duration-300",
          isSearchVisible ? "h-16" : "h-0"
        )}
      >
        <div className="container h-full flex items-center">
          <input
            type="text"
            placeholder="Search articles, topics, or authors..."
            className="w-full h-10 px-4 bg-background border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            autoFocus={isSearchVisible}
          />
        </div>
      </div>
    </header>
  );
}