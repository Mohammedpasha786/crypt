import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useIsMobile } from "@/hooks/use-mobile";

interface FeaturedPostProps {
  id: string;
  title: string;
  excerpt: string;
  coverImage: string;
  category: string;
  author: {
    name: string;
    avatar: string;
  };
  publishDate: string;
  readTime: string;
}

export default function FeaturedPost({
  id,
  title,
  excerpt,
  coverImage,
  category,
  author,
  publishDate,
  readTime,
}: FeaturedPostProps) {
  const isMobile = useIsMobile();

  return (
    <div className="relative overflow-hidden rounded-lg border">
      <div className="absolute inset-0 bg-black/50 z-10" />
      <img
        src={coverImage}
        alt={title}
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="relative z-20 p-8 md:p-12 flex flex-col h-full justify-end">
        <div className="max-w-3xl">
          <div className="flex items-center gap-3 mb-4">
            <Badge className="bg-primary hover:bg-primary/90">Featured</Badge>
            <Badge variant="secondary" className="capitalize">
              {category}
            </Badge>
            <span className="text-xs text-white/80">{readTime} read</span>
          </div>
          <h1 className="text-2xl md:text-4xl font-bold text-white mb-4">
            {title}
          </h1>
          {!isMobile && (
            <p className="text-white/90 text-lg mb-6 line-clamp-2">
              {excerpt}
            </p>
          )}
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 mb-6 sm:mb-0">
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8 border-2 border-white">
                <AvatarImage src={author.avatar} alt={author.name} />
                <AvatarFallback className="bg-primary text-white">
                  {author.name.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="text-sm font-medium text-white">
                  {author.name}
                </div>
                <div className="text-xs text-white/70">{publishDate}</div>
              </div>
            </div>
            <Button asChild size="lg">
              <Link to={`/article/${id}`}>Read Article</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}