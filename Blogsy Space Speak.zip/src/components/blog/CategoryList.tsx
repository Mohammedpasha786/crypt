import { Link } from "react-router-dom";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter,
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Category {
  id: string;
  name: string;
  description: string;
  postCount: number;
  icon: React.ReactNode;
}

interface CategoryListProps {
  categories: Category[];
}

export default function CategoryList({ categories }: CategoryListProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {categories.map((category) => (
        <Link 
          key={category.id} 
          to={`/categories/${category.id}`}
          className="block h-full"
        >
          <Card className="h-full transition-all hover:shadow-md hover:border-primary/50">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div className="p-2 bg-primary/10 rounded-md">
                  {category.icon}
                </div>
                <Badge variant="outline">{category.postCount} posts</Badge>
              </div>
              <CardTitle className="mt-4">{category.name}</CardTitle>
              <CardDescription className="line-clamp-2">
                {category.description}
              </CardDescription>
            </CardHeader>
            <CardFooter className="text-sm text-primary pt-0">
              Browse articles
            </CardFooter>
          </Card>
        </Link>
      ))}
    </div>
  );
}