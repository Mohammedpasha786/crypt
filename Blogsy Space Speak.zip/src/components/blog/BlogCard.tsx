import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface BlogCardProps {
  id: string;
  title: string;
  excerpt: string;
  coverImage: string;
  category: string;
  author: {
    name: string;
    avatar: string;
  };
  publishDate: string;
  readTime: string;
  featured?: boolean;
  className?: string;
}

export default function BlogCard({
  id,
  title,
  excerpt,
  coverImage,
  category,
  author,
  publishDate,
  readTime,
  featured = false,
  className = "",
}: BlogCardProps) {
  return (
    <Link to={`/article/${id}`} className={`block ${className}`}>
      <Card className={`h-full overflow-hidden blog-card ${featured ? "border-primary/20" : ""}`}>
        <div className="relative aspect-video overflow-hidden">
          <img
            src={coverImage}
            alt={title}
            className="w-full h-full object-cover blog-card-image"
          />
          {featured && (
            <div className="absolute top-2 left-2">
              <Badge className="bg-primary hover:bg-primary/90">Featured</Badge>
            </div>
          )}
        </div>
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="secondary" className="capitalize">
              {category}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {readTime} read
            </span>
          </div>
          <h3 className="text-xl font-semibold line-clamp-2 mb-2 hover:text-primary transition-colors">
            {title}
          </h3>
          <p className="text-muted-foreground line-clamp-2 text-sm">
            {excerpt}
          </p>
        </CardContent>
        <CardFooter className="p-5 pt-0 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={author.avatar} alt={author.name} />
              <AvatarFallback>
                {author.name.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <span className="text-sm font-medium">{author.name}</span>
          </div>
          <span className="text-xs text-muted-foreground">{publishDate}</span>
        </CardFooter>
      </Card>
    </Link>
  );
}