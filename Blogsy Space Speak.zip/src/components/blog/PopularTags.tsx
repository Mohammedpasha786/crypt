import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface Tag {
  id: string;
  name: string;
  count: number;
}

interface PopularTagsProps {
  tags: Tag[];
}

export default function PopularTags({ tags }: PopularTagsProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Popular Tags</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <Link key={tag.id} to={`/tags/${tag.id}`}>
              <Badge variant="secondary" className="hover:bg-secondary/80">
                {tag.name}
                <span className="ml-1 text-xs text-muted-foreground">
                  ({tag.count})
                </span>
              </Badge>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}