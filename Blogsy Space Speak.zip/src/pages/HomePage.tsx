import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import Layout from "@/components/layout/Layout";
import FeaturedPost from "@/components/blog/FeaturedPost";
import BlogCard from "@/components/blog/BlogCard";
import CategoryList from "@/components/blog/CategoryList";
import NewsletterSubscribe from "@/components/blog/NewsletterSubscribe";
import PopularTags from "@/components/blog/PopularTags";
import { articles, categories, tags } from "@/data/mockData";
import { PenSquare, ChevronRight } from "lucide-react";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("latest");
  
  const featuredPost = articles.find(article => article.featured);
  const latestArticles = [...articles].sort((a, b) => 
    new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
  ).slice(0, 6);
  
  const popularArticles = [...articles].sort(() => Math.random() - 0.5).slice(0, 6);
  
  return (
    <Layout>
      {/* Hero Section */}
      <section className="container py-8 md:py-12">
        {featuredPost && (
          <FeaturedPost
            id={featuredPost.id}
            title={featuredPost.title}
            excerpt={featuredPost.excerpt}
            coverImage={featuredPost.coverImage}
            category={featuredPost.category}
            author={featuredPost.author}
            publishDate={featuredPost.publishDate}
            readTime={featuredPost.readTime}
          />
        )}
      </section>
      
      {/* Main Content */}
      <section className="container py-8 md:py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Articles Section */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Latest Articles</h2>
              <Button variant="ghost" asChild>
                <Link to="/articles" className="gap-1 flex items-center">
                  View All
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
            
            <Tabs defaultValue="latest" className="mb-8">
              <TabsList className="mb-6">
                <TabsTrigger value="latest" onClick={() => setActiveTab("latest")}>
                  Latest
                </TabsTrigger>
                <TabsTrigger value="popular" onClick={() => setActiveTab("popular")}>
                  Popular
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="latest" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {latestArticles.map((article) => (
                    <BlogCard
                      key={article.id}
                      id={article.id}
                      title={article.title}
                      excerpt={article.excerpt}
                      coverImage={article.coverImage}
                      category={article.category}
                      author={article.author}
                      publishDate={article.publishDate}
                      readTime={article.readTime}
                      featured={article.featured}
                    />
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="popular" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {popularArticles.map((article) => (
                    <BlogCard
                      key={article.id}
                      id={article.id}
                      title={article.title}
                      excerpt={article.excerpt}
                      coverImage={article.coverImage}
                      category={article.category}
                      author={article.author}
                      publishDate={article.publishDate}
                      readTime={article.readTime}
                      featured={article.featured}
                    />
                  ))}
                </div>
              </TabsContent>
            </Tabs>
            
            {/* Start Writing CTA */}
            <div className="border rounded-lg p-6 md:p-8 bg-muted/30 flex flex-col md:flex-row items-center justify-between gap-4 md:gap-6 mb-8">
              <div>
                <h3 className="text-xl font-bold mb-2">Have something to share?</h3>
                <p className="text-muted-foreground">
                  Share your knowledge and experience with our community.
                </p>
              </div>
              <Button asChild size="lg" className="gap-2">
                <Link to="/create">
                  <PenSquare className="h-4 w-4" />
                  Start Writing
                </Link>
              </Button>
            </div>
            
            {/* Popular Tags */}
            <PopularTags tags={tags.slice(0, 12)} />
          </div>
          
          {/* Sidebar */}
          <div className="lg:w-80 space-y-6">
            <NewsletterSubscribe />
            
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Explore Categories</h3>
              <div className="space-y-2">
                {categories.slice(0, 6).map((category) => (
                  <Link
                    key={category.id}
                    to={`/categories/${category.id}`}
                    className="flex items-center justify-between p-2 rounded-md hover:bg-secondary group"
                  >
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-primary/10 rounded-md">
                        {category.icon}
                      </div>
                      <span className="font-medium group-hover:text-primary transition-colors">
                        {category.name}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground bg-secondary rounded-full px-2 py-0.5">
                      {category.postCount}
                    </span>
                  </Link>
                ))}
              </div>
              <Button variant="outline" asChild className="w-full">
                <Link to="/categories">View All Categories</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      {/* Categories Section */}
      <section className="bg-muted/30 py-8 md:py-12">
        <div className="container">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Browse by Category</h2>
            <Button variant="ghost" asChild>
              <Link to="/categories" className="gap-1 flex items-center">
                View All
                <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          
          <CategoryList categories={categories.slice(0, 6)} />
        </div>
      </section>
    </Layout>
  );
}