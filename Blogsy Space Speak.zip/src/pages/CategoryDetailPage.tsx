import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Layout from "@/components/layout/Layout";
import BlogCard from "@/components/blog/BlogCard";
import { categories, articles } from "@/data/mockData";
import { ChevronLeft } from "lucide-react";

export default function CategoryDetailPage() {
  const { id } = useParams<{ id: string }>();
  const category = categories.find((c) => c.id === id);
  const categoryArticles = articles.filter((a) => a.categoryId === id);

  if (!category) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Category Not Found</h1>
          <p className="text-muted-foreground mb-6">
            The category you are looking for does not exist or has been removed.
          </p>
          <Button asChild>
            <Link to="/categories">Browse Categories</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="container py-8 md:py-12">
        {/* Back Button */}
        <div className="mb-8">
          <Button variant="ghost" asChild className="gap-1">
            <Link to="/categories">
              <ChevronLeft className="h-4 w-4" />
              Back to Categories
            </Link>
          </Button>
        </div>

        <div className="flex flex-col items-center text-center mb-12">
          <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            {category.icon}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{category.name}</h1>
          <p className="text-muted-foreground max-w-2xl">
            {category.description}
          </p>
        </div>

        {categoryArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categoryArticles.map((article) => (
              <BlogCard
                key={article.id}
                id={article.id}
                title={article.title}
                excerpt={article.excerpt}
                coverImage={article.coverImage}
                category={article.category}
                author={article.author}
                publishDate={article.publishDate}
                readTime={article.readTime}
                featured={article.featured}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <h2 className="text-xl font-semibold mb-2">No articles yet</h2>
            <p className="text-muted-foreground mb-6">
              There are no articles in this category yet. Be the first to contribute!
            </p>
            <Button asChild>
              <Link to="/create">Write an Article</Link>
            </Button>
          </div>
        )}
      </section>
    </Layout>
  );
}