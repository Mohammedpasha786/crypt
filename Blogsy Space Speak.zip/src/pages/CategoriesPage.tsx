import Layout from "@/components/layout/Layout";
import CategoryList from "@/components/blog/CategoryList";
import { categories } from "@/data/mockData";

export default function CategoriesPage() {
  return (
    <Layout>
      <section className="container py-8 md:py-12">
        <div className="flex flex-col items-center text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Categories</h1>
          <p className="text-muted-foreground max-w-2xl">
            Browse our articles by topic to find the information that's most relevant to you.
          </p>
        </div>

        <CategoryList categories={categories} />
      </section>
    </Layout>
  );
}