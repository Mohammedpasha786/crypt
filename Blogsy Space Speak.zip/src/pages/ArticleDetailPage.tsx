import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Layout from "@/components/layout/Layout";
import BlogCard from "@/components/blog/BlogCard";
import { articles } from "@/data/mockData";
import { 
  Calendar, 
  Clock, 
  MessageSquare, 
  Share2, 
  ThumbsUp, 
  ChevronLeft 
} from "lucide-react";
import { useEffect } from "react";

export default function ArticleDetailPage() {
  const { id } = useParams<{ id: string }>();
  const article = articles.find(a => a.id === id);
  
  const relatedArticles = articles
    .filter(a => a.id !== id && a.categoryId === article?.categoryId)
    .slice(0, 3);
    
  // Scroll to top when article changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);
  
  if (!article) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Article Not Found</h1>
          <p className="text-muted-foreground mb-6">
            The article you are looking for does not exist or has been removed.
          </p>
          <Button asChild>
            <Link to="/articles">Browse Articles</Link>
          </Button>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <article className="container py-8 md:py-12">
        {/* Back Button */}
        <div className="mb-8">
          <Button variant="ghost" asChild className="gap-1">
            <Link to="/articles">
              <ChevronLeft className="h-4 w-4" />
              Back to Articles
            </Link>
          </Button>
        </div>
        
        {/* Article Header */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 mb-4">
            <Badge variant="secondary" className="capitalize">
              {article.category}
            </Badge>
            {article.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline">
                {tag}
              </Badge>
            ))}
          </div>
          
          <h1 className="text-3xl md:text-4xl font-bold mb-6">{article.title}</h1>
          
          <div className="flex flex-wrap items-center gap-4 md:gap-6 mb-8">
            <div className="flex items-center gap-2">
              <Avatar className="h-10 w-10">
                <AvatarImage src={article.author.avatar} alt={article.author.name} />
                <AvatarFallback>
                  {article.author.name.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium">{article.author.name}</div>
                <div className="text-xs text-muted-foreground">Author</div>
              </div>
            </div>
            
            <div className="flex items-center gap-1 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span className="text-sm">{article.publishDate}</span>
            </div>
            
            <div className="flex items-center gap-1 text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span className="text-sm">{article.readTime} read</span>
            </div>
          </div>
          
          {/* Featured Image */}
          <div className="rounded-lg overflow-hidden mb-8">
            <img
              src={article.coverImage}
              alt={article.title}
              className="w-full h-auto max-h-[500px] object-cover"
            />
          </div>
        </div>
        
        {/* Article Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8">
            {/* Social Sharing Sidebar */}
            <div className="relative">
              <div className="hidden lg:flex flex-col gap-3 absolute left-0 top-0 transform -translate-x-16">
                <Button variant="outline" size="icon" className="rounded-full">
                  <ThumbsUp className="h-5 w-5" />
                  <span className="sr-only">Like</span>
                </Button>
                <Button variant="outline" size="icon" className="rounded-full">
                  <MessageSquare className="h-5 w-5" />
                  <span className="sr-only">Comment</span>
                </Button>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Share2 className="h-5 w-5" />
                  <span className="sr-only">Share</span>
                </Button>
              </div>
              
              {/* Article Content */}
              <div className="prose max-w-none blog-content">
                <div dangerouslySetInnerHTML={{ __html: article.content }} />
              </div>
              
              {/* Tags */}
              <div className="mt-8">
                <h3 className="text-lg font-semibold mb-2">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {article.tags.map((tag) => (
                    <Badge key={tag} variant="outline">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              
              {/* Mobile Actions */}
              <div className="flex items-center justify-between mt-8 lg:hidden">
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon">
                    <ThumbsUp className="h-5 w-5" />
                    <span className="sr-only">Like</span>
                  </Button>
                  <Button variant="outline" size="icon">
                    <MessageSquare className="h-5 w-5" />
                    <span className="sr-only">Comment</span>
                  </Button>
                  <Button variant="outline" size="icon">
                    <Share2 className="h-5 w-5" />
                    <span className="sr-only">Share</span>
                  </Button>
                </div>
              </div>
              
              {/* Author Card */}
              <Card className="mt-8">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={article.author.avatar} alt={article.author.name} />
                      <AvatarFallback>
                        {article.author.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle>{article.author.name}</CardTitle>
                      <CardDescription>Author</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    {article.author.bio || "Writer and content creator specializing in technology and development."}
                  </p>
                </CardContent>
              </Card>
              
              {/* Comments Section Placeholder */}
              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-4">Comments</h3>
                <Card>
                  <CardContent className="p-6">
                    <p className="text-center text-muted-foreground py-8">
                      Comments feature coming soon. Share your thoughts on this article!
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-4 space-y-8">
            {/* Related Articles */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Related Articles</h3>
              <div className="space-y-6">
                {relatedArticles.map((relatedArticle) => (
                  <BlogCard
                    key={relatedArticle.id}
                    id={relatedArticle.id}
                    title={relatedArticle.title}
                    excerpt={relatedArticle.excerpt}
                    coverImage={relatedArticle.coverImage}
                    category={relatedArticle.category}
                    author={relatedArticle.author}
                    publishDate={relatedArticle.publishDate}
                    readTime={relatedArticle.readTime}
                    className="h-auto"
                  />
                ))}
                
                {relatedArticles.length === 0 && (
                  <p className="text-muted-foreground">No related articles found.</p>
                )}
              </div>
              
              <Separator className="my-8" />
              
              <div className="bg-muted/30 p-6 rounded-lg">
                <h3 className="font-semibold mb-3">Want to write for Blogsy?</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Share your knowledge and expertise with our community of developers and tech enthusiasts.
                </p>
                <Button asChild size="sm" className="w-full">
                  <Link to="/create">Start Writing</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </article>
    </Layout>
  );
}