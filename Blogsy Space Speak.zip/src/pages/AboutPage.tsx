import { Button } from "@/components/ui/button";
import Layout from "@/components/layout/Layout";
import { Link } from "react-router-dom";
import { MessageSquare, PenSquare, Users } from "lucide-react";
import { authors } from "@/data/mockData";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function AboutPage() {
  return (
    <Layout>
      <section className="container py-8 md:py-12">
        <div className="flex flex-col items-center text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">About Blogsy</h1>
          <p className="text-muted-foreground max-w-2xl">
            Your space to speak and connect with a community of tech enthusiasts, developers, and creative minds.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="mb-4 text-muted-foreground">
              At Blogsy, we believe that knowledge sharing drives innovation and growth in the tech community. 
              Our platform is designed to give developers, designers, and technology enthusiasts a place to 
              share their insights, experiences, and expertise.
            </p>
            <p className="mb-4 text-muted-foreground">
              We're dedicated to creating a space where quality content thrives, where ideas can be 
              exchanged freely, and where everyone from beginners to experts can find valuable information 
              to help them on their journey.
            </p>
          </div>
          <div className="rounded-lg overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&h=600&fit=crop" 
              alt="Team collaboration" 
              className="w-full h-auto object-cover" 
            />
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-8 text-center">What We Offer</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <PenSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Quality Content</h3>
              <p className="text-muted-foreground">
                Articles, tutorials, and guides written by industry professionals and passionate technologists.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Community</h3>
              <p className="text-muted-foreground">
                A supportive environment where you can connect with like-minded professionals and enthusiasts.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <MessageSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Engagement</h3>
              <p className="text-muted-foreground">
                Interactive discussions, feedback, and opportunities to engage with content creators.
              </p>
            </div>
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-8 text-center">Our Team</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {authors.map((author) => (
              <div key={author.id} className="flex flex-col items-center text-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={author.avatar} alt={author.name} />
                  <AvatarFallback>
                    {author.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <h3 className="text-lg font-semibold">{author.name}</h3>
                <p className="text-sm text-muted-foreground mt-1 mb-3">
                  {author.bio}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-muted/30 p-8 md:p-12 rounded-lg text-center">
          <h2 className="text-2xl font-bold mb-4">Join Our Community</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
            Share your knowledge, learn from others, and be part of a growing community of tech enthusiasts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg">
              <Link to="/create">Start Writing</Link>
            </Button>
            <Button variant="outline" asChild size="lg">
              <Link to="/articles">Browse Articles</Link>
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}