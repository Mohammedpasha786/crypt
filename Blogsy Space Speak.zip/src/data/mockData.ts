import { 
  Code, 
  ImageIcon, 
  Languages, 
  LayoutDashboard, 
  Lightbulb, 
  Settings, 
  TrendingUp, 
  Database,
  Code2,
  Globe,
} from "lucide-react";

export interface Author {
  id: string;
  name: string;
  avatar: string;
  bio?: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: string;
  categoryId: string;
  author: Author;
  publishDate: string;
  readTime: string;
  featured?: boolean;
  tags: string[];
}

export interface Category {
  id: string;
  name: string;
  description: string;
  postCount: number;
  icon: JSX.Element;
}

export interface Tag {
  id: string;
  name: string;
  count: number;
}

export const authors: Author[] = [
  {
    id: "author-1",
    name: "Alex Johnson",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
    bio: "Full Stack Developer and tech enthusiast with 8+ years of experience in web development."
  },
  {
    id: "author-2",
    name: "Sarah Williams",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
    bio: "UI/UX designer passionate about creating beautiful and functional user experiences."
  },
  {
    id: "author-3",
    name: "Michael Chen",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    bio: "DevOps engineer with a focus on cloud infrastructure and automation."
  },
  {
    id: "author-4",
    name: "Emma Wilson",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
    bio: "Backend developer specializing in database optimization and API design."
  }
];

export const articles: Article[] = [
  {
    id: "article-1",
    title: "Building RESTful APIs with Node.js and Express",
    slug: "building-restful-apis-with-nodejs-and-express",
    excerpt: "Learn how to create robust, scalable APIs using Node.js and Express that follow REST principles.",
    content: `
# Building RESTful APIs with Node.js and Express

REST APIs are the backbone of modern web applications, enabling seamless communication between frontend and backend systems. In this comprehensive guide, we'll explore how to build efficient, scalable, and maintainable RESTful APIs using Node.js and Express.

## What is a RESTful API?

REST (Representational State Transfer) is an architectural style for designing networked applications. RESTful APIs use HTTP requests to perform CRUD operations (Create, Read, Update, Delete) on resources, which are represented as URLs.

## Setting Up Your Project

First, let's initialize a new Node.js project:

\`\`\`bash
mkdir rest-api-demo
cd rest-api-demo
npm init -y
npm install express mongoose dotenv cors
\`\`\`

## Creating the Server

Let's start by creating a basic Express server:

\`\`\`javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.get('/', (req, res) => {
  res.send('REST API is running!');
});

// Start server
app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});
\`\`\`

## Connecting to MongoDB

Next, let's connect to MongoDB using Mongoose:

\`\`\`javascript
const mongoose = require('mongoose');

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log('MongoDB connection error:', err));
\`\`\`

## Creating Models

Now, let's define a simple model for our API:

\`\`\`javascript
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('User', UserSchema);
\`\`\`

## Implementing CRUD Routes

Let's implement the CRUD operations for our User model:

\`\`\`javascript
const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Get all users
router.get('/', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get one user
router.get('/:id', getUser, (req, res) => {
  res.json(res.user);
});

// Create a user
router.post('/', async (req, res) => {
  const user = new User({
    name: req.body.name,
    email: req.body.email,
    role: req.body.role
  });

  try {
    const newUser = await user.save();
    res.status(201).json(newUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update a user
router.patch('/:id', getUser, async (req, res) => {
  if (req.body.name != null) {
    res.user.name = req.body.name;
  }
  if (req.body.email != null) {
    res.user.email = req.body.email;
  }
  if (req.body.role != null) {
    res.user.role = req.body.role;
  }

  try {
    const updatedUser = await res.user.save();
    res.json(updatedUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete a user
router.delete('/:id', getUser, async (req, res) => {
  try {
    await res.user.remove();
    res.json({ message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Middleware to get user by ID
async function getUser(req, res, next) {
  try {
    const user = await User.findById(req.params.id);
    if (user == null) {
      return res.status(404).json({ message: 'Cannot find user' });
    }
    res.user = user;
    next();
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

module.exports = router;
\`\`\`

## Error Handling

Proper error handling is crucial for a robust API:

\`\`\`javascript
// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: true,
    message: 'Internal Server Error',
    stack: process.env.NODE_ENV === 'production' ? '🥞' : err.stack
  });
});
\`\`\`

## API Documentation

Consider using tools like Swagger to document your API:

\`\`\`javascript
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'User API',
      version: '1.0.0',
      description: 'A simple Express User API',
    },
  },
  apis: ['./routes/*.js'],
};

const specs = swaggerJsdoc(options);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));
\`\`\`

## Conclusion

Building RESTful APIs with Node.js and Express is straightforward and powerful. By following REST principles and best practices, you can create APIs that are:

1. Scalable and maintainable
2. Easy to integrate with other systems
3. Well-documented and developer-friendly

Remember to implement proper authentication, validation, and testing for production-ready APIs.
    `,
    coverImage: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200&h=800&fit=crop",
    category: "Backend Development",
    categoryId: "backend",
    author: authors[0],
    publishDate: "Jul 15, 2025",
    readTime: "8 min",
    featured: true,
    tags: ["Node.js", "Express", "API", "REST", "MongoDB"]
  },
  {
    id: "article-2",
    title: "React Hooks Deep Dive: useEffect Explained",
    slug: "react-hooks-deep-dive-useeffect-explained",
    excerpt: "Master the useEffect hook in React and learn how to avoid common pitfalls when handling side effects.",
    content: "Extended content for the article",
    coverImage: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=1200&h=800&fit=crop",
    category: "Frontend Development",
    categoryId: "frontend",
    author: authors[1],
    publishDate: "Jul 12, 2025",
    readTime: "5 min",
    featured: false,
    tags: ["React", "JavaScript", "Hooks", "Frontend"]
  },
  {
    id: "article-3",
    title: "Docker Containerization for Modern Applications",
    slug: "docker-containerization-for-modern-applications",
    excerpt: "Learn how to containerize your applications using Docker for consistent deployment and development.",
    content: "Extended content for the article",
    coverImage: "https://images.unsplash.com/photo-1605745341088-3462ce68c371?w=1200&h=800&fit=crop",
    category: "DevOps",
    categoryId: "devops",
    author: authors[2],
    publishDate: "Jul 10, 2025",
    readTime: "10 min",
    featured: false,
    tags: ["Docker", "Containerization", "DevOps", "Deployment"]
  },
  {
    id: "article-4",
    title: "Building Responsive UIs with Tailwind CSS",
    slug: "building-responsive-uis-with-tailwind-css",
    excerpt: "Create beautiful, responsive user interfaces quickly and efficiently using the utility-first CSS framework.",
    content: "Extended content for the article",
    coverImage: "https://images.unsplash.com/photo-1593720219276-0b1eacd0aef4?w=1200&h=800&fit=crop",
    category: "UI Design",
    categoryId: "ui-design",
    author: authors[1],
    publishDate: "Jul 7, 2025",
    readTime: "6 min",
    featured: false,
    tags: ["CSS", "Tailwind", "UI", "Design", "Responsive"]
  },
  {
    id: "article-5",
    title: "PostgreSQL vs. MongoDB: Choosing the Right Database",
    slug: "postgresql-vs-mongodb-choosing-the-right-database",
    excerpt: "Compare the strengths and weaknesses of relational and document databases for your next project.",
    content: "Extended content for the article",
    coverImage: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=1200&h=800&fit=crop",
    category: "Database",
    categoryId: "database",
    author: authors[3],
    publishDate: "Jul 5, 2025",
    readTime: "7 min",
    featured: false,
    tags: ["Database", "PostgreSQL", "MongoDB", "NoSQL", "SQL"]
  },
  {
    id: "article-6",
    title: "TypeScript Best Practices for Large-Scale Applications",
    slug: "typescript-best-practices-for-large-scale-applications",
    excerpt: "Discover how to effectively use TypeScript to build maintainable, large-scale applications.",
    content: "Extended content for the article",
    coverImage: "https://images.unsplash.com/photo-1619410283995-43d9134e7656?w=1200&h=800&fit=crop",
    category: "Frontend Development",
    categoryId: "frontend",
    author: authors[0],
    publishDate: "Jul 3, 2025",
    readTime: "9 min",
    featured: true,
    tags: ["TypeScript", "JavaScript", "Architecture", "Best Practices"]
  }
];

export const categories: Category[] = [
  {
    id: "frontend",
    name: "Frontend Development",
    description: "Articles about JavaScript frameworks, UI libraries, and modern frontend techniques.",
    postCount: 12,
    icon: <Code className="h-5 w-5 text-primary" />
  },
  {
    id: "backend",
    name: "Backend Development",
    description: "Server-side programming, API development, and backend frameworks.",
    postCount: 8,
    icon: <Database className="h-5 w-5 text-primary" />
  },
  {
    id: "devops",
    name: "DevOps",
    description: "Deployment strategies, CI/CD, containers, and cloud infrastructure.",
    postCount: 5,
    icon: <Settings className="h-5 w-5 text-primary" />
  },
  {
    id: "ui-design",
    name: "UI Design",
    description: "User interface design principles, tools, and implementation strategies.",
    postCount: 7,
    icon: <ImageIcon className="h-5 w-5 text-primary" />
  },
  {
    id: "database",
    name: "Database",
    description: "Database design, optimization, and management for various database systems.",
    postCount: 6,
    icon: <LayoutDashboard className="h-5 w-5 text-primary" />
  },
  {
    id: "web3",
    name: "Web3 & Blockchain",
    description: "Blockchain technology, decentralized applications, and smart contracts.",
    postCount: 4,
    icon: <Code2 className="h-5 w-5 text-primary" />
  },
  {
    id: "ai",
    name: "AI & Machine Learning",
    description: "Artificial intelligence, machine learning algorithms, and practical applications.",
    postCount: 3,
    icon: <Lightbulb className="h-5 w-5 text-primary" />
  },
  {
    id: "career",
    name: "Career & Growth",
    description: "Professional development, career advice, and technology industry insights.",
    postCount: 9,
    icon: <TrendingUp className="h-5 w-5 text-primary" />
  },
  {
    id: "languages",
    name: "Programming Languages",
    description: "Deep dives into programming languages, their features, and best practices.",
    postCount: 11,
    icon: <Languages className="h-5 w-5 text-primary" />
  }
];

export const tags: Tag[] = [
  { id: "react", name: "React", count: 15 },
  { id: "javascript", name: "JavaScript", count: 22 },
  { id: "nodejs", name: "Node.js", count: 14 },
  { id: "typescript", name: "TypeScript", count: 11 },
  { id: "python", name: "Python", count: 9 },
  { id: "docker", name: "Docker", count: 8 },
  { id: "aws", name: "AWS", count: 7 },
  { id: "api", name: "API", count: 13 },
  { id: "database", name: "Database", count: 10 },
  { id: "devops", name: "DevOps", count: 6 },
  { id: "web-development", name: "Web Development", count: 18 },
  { id: "ui", name: "UI", count: 12 },
  { id: "ux", name: "UX", count: 8 },
  { id: "tailwind", name: "Tailwind", count: 7 },
  { id: "css", name: "CSS", count: 9 }
];